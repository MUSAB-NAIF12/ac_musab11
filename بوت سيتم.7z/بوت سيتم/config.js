module.exports = {
    TOKEN: 'توكن',    
    YT_API_KEY: 'api ',
    prefix: 'برافكس',
    devs: ['اى دى حقك']
}
